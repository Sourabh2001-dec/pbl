<div class="four columns ranking">
                   <div class="rank_heading">POPULAR POSTS</div>
                    
                    <div class="ranked_post">
                        <div class="rank_num">#1</div>

                        <div class="rank_title">Will AI be the reason for unemployment of engineers?</div>
                        <div class="rank_post_by">
                            POST BY <div class="rank_author">ANONYMOUS</div> ON
                        <div class="rank_date">05/02/2020</div>
                        </div>
                    </div>


                    
                    
                    <div class="ranked_post">
                        <div class="rank_num">#1</div>

                        <div class="rank_title">Will AI be the reason for unemployment of engineers?</div>
                        <div class="rank_post_by">
                            POST BY <div class="rank_author">ANONYMOUS</div> ON
                        <div class="rank_date">05/02/2020</div>
                        </div>
                    </div>



                    
                    
                    <div class="ranked_post">
                        <div class="rank_num">#1</div>

                        <div class="rank_title">Will AI be the reason for unemployment of engineers?</div>
                        <div class="rank_post_by">
                            POST BY <div class="rank_author">ANONYMOUS</div> ON
                        <div class="rank_date">05/02/2020</div>
                        </div>
                    </div>




                    
                    
                    <div class="ranked_post">
                        <div class="rank_num">#1</div>

                        <div class="rank_title">Will AI be the reason for unemployment of engineers?</div>
                        <div class="rank_post_by">
                            POST BY <div class="rank_author">ANONYMOUS</div> ON
                        <div class="rank_date">05/02/2020</div>
                        </div>
                    </div>
                    
                </div>
            </div>