    <link rel="stylesheet" href="vendor\css\bootstrap.min.css">
    <link rel="stylesheet" href="vendor\css\fontawesome.min.css">
    <link rel="stylesheet" href="vendor\css\all.css">
    <script src="vendor/js/jquery.min.js"></script>
    <script src="vendor/js/popper.js"></script>
<script src="vendor/js/bootstrap.min.js"></script>