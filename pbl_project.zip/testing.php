<?php
    if (isset($_POST['save'])) {
        echo $_POST['editor_content'];
    }