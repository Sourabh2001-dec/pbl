<?php
if (isset($_POST['content'])) {
    print_r($_POST);
}