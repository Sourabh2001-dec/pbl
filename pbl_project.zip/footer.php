<footer>
  Copyright &copy; 2020 InfoGeek India. All Rights Reserved
</footer>
